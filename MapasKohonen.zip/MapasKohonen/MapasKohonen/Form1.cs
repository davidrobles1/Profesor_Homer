﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MapasKohonen
{
    public partial class Form1 : Form
    {
        //Variables para la ejecucion del programa
        //N1=neuronas en capa de entrada
        //N2=neuronas en capa de competicion
        //numerolinea=Contador de la linea de lectura del archivo de texto
        //NI=numero de iteraciones
        //P=numero de patrones
        //temp=variable temporal que almacena el numero de la celula ganadora
        int N1 = 0, N2 = 0, numerolinea = 0, NI = 0, P = 0, temp = 0;
        //alfa=la variable alfa para la propagacion de patrones
        //beta=variable beta para la propagacion de patrones
        //S=variable temporal que almacena el acumulado de tao
        //T=variable que almacenara la distancia euqulidiana menor
        //DM=variable temporal para la actualizacion de mu
        double alfa = 0.0, beta = 0.0, S = 0.0, T = 0.0, DM = 0.0;
        //tao=variable de la distancia euclideana de cada patron a cada neurona
        double[] tao;
        //M=pesos de la red
        double[,] M;
        //epsilon=los datos de entrada de la red
        double[] epsilon;
        //patrones=almacena los patrones
        double[,] patrones;
        //patrones2=almacena los patrones ingresados por el usuario
        double[,] patrones2;
        //datos=almacena de manera temporal los datos de lectura del archivo de texto
        string[] datos;

        public Form1()
        {
            InitializeComponent();
        }
        //Boton que realiza la accion de leer el archivo de texto
        private void LA_Click(object sender, EventArgs e)
        {
            //leer el archivo
            StreamReader sr = new StreamReader("C:/Users/TOSHIBA/Desktop/kohonen.txt");
            //guardar los datos de la linea leida en un arreglo
            String linea = sr.ReadLine();
            //verificar cada linea leida
            while (linea != null)
            {
                //segun la linea es la accion
                switch (numerolinea)
                {
                    case 0:
                        //Asignacion de las neuronas de entrada
                        N1 = Convert.ToInt32(linea);
                        break;
                    case 1:
                        //Asignacion de las neuronas de competicion
                        N2 = Convert.ToInt32(linea);
                        break;
                    case 2:
                        //Asignacion de alfa
                        alfa = Convert.ToDouble(linea);
                        break;
                    case 3:
                        //asignacion de las iteraciones
                        NI = Convert.ToInt32(linea);
                        break;
                    case 4:
                        //asignacion de el numero de patrones y declaracion de dimencionas del arreglo de patrones
                        P = Convert.ToInt32(linea);
                        patrones = new double[P, N1];
                        M = new double[N2, N1];
                        tao = new double[N2];
                        patrones2 = new double[2, 2];
                        break;
                }
                //Recorrido de las lineas de los patrones
                if (numerolinea <= P + 5 && numerolinea > 4)
                {
                    if (linea != "")
                    {
                        datos = linea.Split(' ');
                        //Recorrido de lineas para leer los patrones
                        for (int i = 0; i < N1; i++)
                        {
                            //Asignacion de los patrones de entrenamiento
                            patrones[numerolinea-5,i] = Convert.ToInt32(datos[i]);
                        }
                    }
                }
                //Incremento de la linea de lectura del archivo de texto para leer todos los datos
                numerolinea++;
                //se lee la linea en la que se ha realizado el incremento
                linea = sr.ReadLine();
            }
            //Se cierra la lectura del archivo de texto
            sr.Close();
        }
        //Boton que entrena la red neuronal con los datos extraidos del archivo de texto
        private void ENT_Click(object sender, EventArgs e)
        {
            //Se obtiene beta
            beta = alfa / NI;
            //Se crean variables aleatorias para los pesos
            Random dec = new Random();
            int num = 0;
            //Se recorre el arreglo para asignar pesos
            //Se recorren neuronas de entrada
            for (int i = 0; i < N1; i++)
            {
                //Se recorren neuronas de competicion
                for (int j = 0; j < N2; j++)
                {
                    //Se crea el valor aleatorio cercano a 0
                    string cadena = num.ToString() + "." + dec.Next(0, 99999).ToString();
                    //Se asigna el valor aleatorio creado
                    M[j,i] = Convert.ToDouble(cadena);
                }
            }
            //Se crea el ciclo para repetir el numero de iteraciones
            for (int i = 0; i < NI; i++)
            {
                S = 0.0;
                //Se crea el ciclo para repetir el numero de patrones
                for (int j = 0; j < P; j++)
                {
                    //Ciclo para obtener el acumulado para tao
                    //Ciclo que recorre las neuronas de la capa de competicion
                    for (int l = 0; l < N2; l++)
                    {
                        //Se crea el ciclo para obtener el acumulado para tao
                        //Ciclo que recorre las neuronas de la capa de entrada
                        for (int k = 0; k < N1; k++)
                        {
                            //Se obtiene el acumulado elevado al cuadrado para obtener la distancia euclidiana
                            S += Math.Pow((patrones[j, k] - M[l, k]), 2);
                        }
                        //Se obtiene la raiz del acumulado para obtener la distancia euclidiana
                        tao[l] = Math.Sqrt(S);
                    }
                    //Se guarda el numero de neurona de la primera distancia euclidiana
                    temp = 1;
                    //Se guarda el valor de la primera distancia euclidiana
                    T = tao[0];
                    //Ciclo para checar la distancia euclidiana menor
                    for (int l = 1; l < N2; l++)
                    {
                        //Se verifica cual es la distancia euclideana menor
                        if (tao[l] < T)
                        {
                            //Se guarda el dato de la distancia euclidiana menor
                            temp = l;
                            //Se guarda el valr de la menor distancia euclidiana
                            T = tao[l];
                        }
                    }
                    //Ciclo para actualizar pesos de la neurona ganadora
                    for (int l = 0; l < N1; l++)
                    {
                        //Se obtiene la diferencia de mu
                        DM = alfa * (patrones[j, l] - M[l, temp]);
                        //Se actualiza el peso de mu de la neurona ganadora
                        M[l, temp] = M[l, temp] - DM;
                    }
                }
                //Se decrementa alfa
                alfa = alfa - beta;
            }

        }
        //Boton que propaga los datos extraidos desde los textbox de la parte grafica
        private void PROP_Click(object sender, EventArgs e)
        {
            if (TXTX.Text!="" && TXTY.Text!="")
            {
                //Se asigna el primer dato para que lo propage la red neuronal
                patrones2[0, 0] = Convert.ToDouble(TXTX.Text);
                //Se asigna el segundo dato para que lo propage la red neuronal
                patrones2[0, 1] = Convert.ToDouble(TXTY.Text);
                //Ciclo para obtener el acumulado para tao
                //Ciclo que recorre las neuronas de la capa de competicion
                for (int l = 0; l < N2; l++)
                {
                    //Se crea el ciclo para obtener el acumulado para tao
                    //Ciclo que recorre las neuronas de la capa de entrada
                    for (int k = 0; k < N1; k++)
                    {
                        //Se obtiene el acumulado elevado al cuadrado para obtener la distancia euclidiana
                        S += Math.Pow((patrones2[0, k] - M[l,k]), 2);
                    }
                    //Se obtiene la raiz del acumulado para obtener la distancia euclidiana
                    tao[l] = Math.Sqrt(S);
                }
                //Se guarda el numero de neurona de la primera distancia euclidiana
                temp = 1;
                //Se guarda el valor de la primera distancia euclidiana
                T = tao[0];
                //Ciclo para checar la distancia euclidiana menor
                for (int l = 1; l < N2; l++)
                {
                    //Se verifica cual es la distancia euclideana menor
                    if (tao[l] < T)
                    {
                        //Se guarda el dato de la distancia euclidiana menor
                        temp = l;
                        //Se guarda el valr de la menor distancia euclidiana
                        T = tao[l];
                    }
                }
                //Se imprime el numero de la neurona ganadora en un label
                NG.Text = "" + temp;
                //Asignamos los datos ingresados en los textbox para graficarlos
                //chart1.Series[0].Points.AddXY(patrones2[0,0], patrones2[0,1]);
            }
        }
        //Boton que grafica los datos entrenados
        private void GRAF_Click(object sender, EventArgs e)
        {
            //Recorremos los patrones para graficar
            for (int i = 0; i < P; i++)
            {
                //Asignamos los puntos a graficar, de los patrones
                //chart1.Series[0].Points.AddXY(patrones[i,0], patrones[i,1]);
            }
            //Recorremos los pesos de las neuronas de la capa de competicion para graficarlos
            for (int i = 0; i < N2; i++)
            {
                //Asignamos los puntos a graficar, de las neuronas usando los pesos de cada entrada
                //chart1.Series[0].Points.AddXY(M[i, 0], M[i, 1]);
            }
        }
    }
}

﻿namespace MapasKohonen
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.LA = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ENT = new System.Windows.Forms.Button();
            this.PROP = new System.Windows.Forms.Button();
            this.TXTX = new System.Windows.Forms.TextBox();
            this.TXTY = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.NG = new System.Windows.Forms.Label();
            this.GRAF = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // LA
            // 
            this.LA.BackColor = System.Drawing.Color.PaleGreen;
            this.LA.Location = new System.Drawing.Point(13, 13);
            this.LA.Name = "LA";
            this.LA.Size = new System.Drawing.Size(75, 23);
            this.LA.TabIndex = 0;
            this.LA.Text = "Leer TXT";
            this.LA.UseVisualStyleBackColor = false;
            this.LA.Click += new System.EventHandler(this.LA_Click);
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.Transparent;
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(13, 62);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(582, 487);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // ENT
            // 
            this.ENT.BackColor = System.Drawing.Color.PaleGreen;
            this.ENT.Location = new System.Drawing.Point(112, 14);
            this.ENT.Name = "ENT";
            this.ENT.Size = new System.Drawing.Size(75, 23);
            this.ENT.TabIndex = 2;
            this.ENT.Text = "Entrenar";
            this.ENT.UseVisualStyleBackColor = false;
            this.ENT.Click += new System.EventHandler(this.ENT_Click);
            // 
            // PROP
            // 
            this.PROP.BackColor = System.Drawing.Color.PaleGreen;
            this.PROP.Location = new System.Drawing.Point(371, 14);
            this.PROP.Name = "PROP";
            this.PROP.Size = new System.Drawing.Size(75, 23);
            this.PROP.TabIndex = 3;
            this.PROP.Text = "Propagar";
            this.PROP.UseVisualStyleBackColor = false;
            this.PROP.Click += new System.EventHandler(this.PROP_Click);
            // 
            // TXTX
            // 
            this.TXTX.BackColor = System.Drawing.Color.GreenYellow;
            this.TXTX.Location = new System.Drawing.Point(201, 36);
            this.TXTX.Name = "TXTX";
            this.TXTX.Size = new System.Drawing.Size(73, 20);
            this.TXTX.TabIndex = 4;
            // 
            // TXTY
            // 
            this.TXTY.BackColor = System.Drawing.Color.GreenYellow;
            this.TXTY.Location = new System.Drawing.Point(280, 36);
            this.TXTY.Name = "TXTY";
            this.TXTY.Size = new System.Drawing.Size(74, 20);
            this.TXTY.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(240, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(309, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Y";
            // 
            // NG
            // 
            this.NG.AutoSize = true;
            this.NG.Location = new System.Drawing.Point(501, 24);
            this.NG.Name = "NG";
            this.NG.Size = new System.Drawing.Size(96, 13);
            this.NG.TabIndex = 8;
            this.NG.Text = "Neurona ganadora";
            // 
            // GRAF
            // 
            this.GRAF.BackColor = System.Drawing.Color.PaleGreen;
            this.GRAF.Location = new System.Drawing.Point(371, 44);
            this.GRAF.Name = "GRAF";
            this.GRAF.Size = new System.Drawing.Size(75, 23);
            this.GRAF.TabIndex = 9;
            this.GRAF.Text = "Graficar";
            this.GRAF.UseVisualStyleBackColor = false;
            this.GRAF.Click += new System.EventHandler(this.GRAF_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(619, 561);
            this.Controls.Add(this.GRAF);
            this.Controls.Add(this.NG);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TXTY);
            this.Controls.Add(this.TXTX);
            this.Controls.Add(this.PROP);
            this.Controls.Add(this.ENT);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.LA);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button LA;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button ENT;
        private System.Windows.Forms.Button PROP;
        private System.Windows.Forms.TextBox TXTX;
        private System.Windows.Forms.TextBox TXTY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label NG;
        private System.Windows.Forms.Button GRAF;
    }
}

